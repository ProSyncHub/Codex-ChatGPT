from flask import Flask, request, jsonify, send_from_directory
import pdfplumber
import re
import os

app = Flask(__name__, static_folder="static")

# ── helpers ──────────────────────────────────────────────────────────────────

def parse_time(s):
    """'3h 4m' or '0h 22m' → total minutes"""
    s = s.strip()
    h = re.search(r'(\d+)h', s)
    m = re.search(r'(\d+)m', s)
    return (int(h.group(1)) if h else 0) * 60 + (int(m.group(1)) if m else 0)

def fmt_time(minutes):
    """minutes → '3h 04m'"""
    return f"{minutes // 60}h {minutes % 60:02d}m"

def extract_text(pdf_file):
    text = ""
    with pdfplumber.open(pdf_file) as pdf:
        for page in pdf.pages:
            text += (page.extract_text() or "") + "\n"
    return text

# ── parsers ───────────────────────────────────────────────────────────────────

def parse_timesheet(text):
    """Extract attendance row from Daily Timesheet PDF."""
    result = {}
    # match row like: WW2909 Harshita Intern  IT  09:57  18:32  8h 35m  8h 9m  8h 9m  0h 25m
    pattern = re.search(
        r'(\w+)\s+([\w\s]+?)\s+(IT|HR|Sales|Marketing|Ops|Operations)?\s*'
        r'(\d{2}:\d{2})\s+(\d{2}:\d{2})\s+'
        r'(\d+h\s*\d+m)\s+(\d+h\s*\d+m)\s+(\d+h\s*\d+m)\s+(\d+h\s*\d+m)',
        text
    )
    if pattern:
        result['emp_id']      = pattern.group(1)
        result['name']        = pattern.group(2).strip()
        result['dept']        = pattern.group(3) or 'IT'
        result['login']       = pattern.group(4)
        result['logout']      = pattern.group(5)
        result['total_hrs']   = pattern.group(6)
        result['working_hrs'] = pattern.group(7)
        result['productive_hrs'] = pattern.group(8)
        result['away_hrs']    = pattern.group(9)

        total_min  = parse_time(result['total_hrs'])
        prod_min   = parse_time(result['productive_hrs'])
        away_min   = parse_time(result['away_hrs'])

        result['prod_pct']  = round(prod_min / total_min * 100, 1) if total_min else 0
        result['away_pct']  = round(away_min / total_min * 100, 1) if total_min else 0
        result['total_min'] = total_min
        result['prod_min']  = prod_min
        result['away_min']  = away_min

        # login variance (assume 9:30 expected)
        lh, lm = map(int, result['login'].split(':'))
        login_min = lh * 60 + lm
        expected_login = 9 * 60 + 30
        result['login_delta'] = login_min - expected_login  # positive = late
    return result

def parse_app_usage(text):
    """Extract app/URL rows from App Usage Report PDF."""
    apps = []
    # match lines like: canva.com  Productive  1h 45m  21.59%
    pattern = re.finditer(
        r'([\w.\-]+(?:\.exe|\.com|\.in|\.io)?)\s+'
        r'(Productive|Unproductive|Neutral)\s+'
        r'(\d+h\s*\d+m)\s+'
        r'([\d.]+)%',
        text
    )
    for m in pattern:
        name = m.group(1)
        mins = parse_time(m.group(3))
        pct  = float(m.group(4))
        if mins == 0 and pct < 0.1:
            continue  # skip near-zero entries
        apps.append({
            'name': name,
            'type': m.group(2),
            'time': m.group(3).strip(),
            'pct':  pct,
            'mins': mins
        })
    # sort by mins desc
    apps.sort(key=lambda x: x['mins'], reverse=True)
    return apps

def classify_app(name):
    core = ['docs.google.com','teams.live.com','canva.com','live.wati.io',
            'mail.google.com','jamandsugar.com','drive.google.com','docs.google']
    semi = ['web.whatsapp.com','chatgpt.com','whatsapp']
    off  = ['instagram.com','amazon.in','facebook.com','youtube.com','netflix.com']
    nl = name.lower()
    if any(c in nl for c in core): return 'core'
    if any(s in nl for s in semi): return 'semi'
    if any(o in nl for o in off):  return 'off'
    return 'core'

def parse_task_log(raw_text):
    """Parse manually entered task log lines: TaskName HH:MM:SS"""
    tasks = []
    for line in raw_text.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        # match  "Task Name  0:45:00"  or  "Task Name  45"
        m = re.search(r'^(.+?)\s+((\d+):(\d+):(\d+)|(\d+))$', line)
        if m:
            name = m.group(1).strip()
            if m.group(3):
                mins = int(m.group(3)) * 60 + int(m.group(4))
            else:
                mins = int(m.group(6))
            tasks.append({'name': name, 'mins': mins, 'time': fmt_time(mins)})
    total = sum(t['mins'] for t in tasks)
    for t in tasks:
        t['pct'] = round(t['mins'] / total * 100, 1) if total else 0
    return tasks, total

def score_employee(ts, apps):
    """Compute simple 0-10 scores."""
    prod_score = min(10, ts.get('prod_pct', 0) / 10)
    # time discipline: penalise late login
    delta = ts.get('login_delta', 0)
    discipline = max(0, 10 - max(0, delta) / 6)
    # off-task penalty
    off_mins = sum(a['mins'] for a in apps if classify_app(a['name']) == 'off')
    total_tracked = sum(a['mins'] for a in apps) or 1
    off_pct = off_mins / total_tracked * 100
    focus = max(0, 10 - off_pct / 5)
    execution = (prod_score + focus) / 2
    overall = round((prod_score + discipline + focus + execution) / 4, 1)

    if overall >= 8.5:   classification = "High Performer"
    elif overall >= 7.0: classification = "Stable Performer"
    elif overall >= 5.5: classification = "Average Contributor"
    elif overall >= 4.0: classification = "Underperforming"
    else:                classification = "Needs Immediate Attention"

    return {
        'overall':    overall,
        'productivity': round(prod_score, 1),
        'discipline':   round(discipline, 1),
        'focus':        round(focus, 1),
        'execution':    round(execution, 1),
        'classification': classification
    }

# ── routes ────────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    timesheet_text = ""
    app_usage_text = ""

    if 'timesheet_pdf' in request.files and request.files['timesheet_pdf'].filename:
        timesheet_text = extract_text(request.files['timesheet_pdf'])
    elif request.form.get('timesheet_text'):
        timesheet_text = request.form['timesheet_text']

    if 'app_usage_pdf' in request.files and request.files['app_usage_pdf'].filename:
        app_usage_text = extract_text(request.files['app_usage_pdf'])
    elif request.form.get('app_usage_text'):
        app_usage_text = request.form['app_usage_text']

    task_log_raw = request.form.get('task_log', '')

    ts   = parse_timesheet(timesheet_text)
    apps = parse_app_usage(app_usage_text)
    tasks, task_total_mins = parse_task_log(task_log_raw)
    scores = score_employee(ts, apps)

    # unlogged gap
    prod_min = ts.get('prod_min', 0)
    gap_min  = max(0, prod_min - task_total_mins)

    return jsonify({
        'timesheet': ts,
        'apps':      apps,
        'tasks':     tasks,
        'task_total': fmt_time(task_total_mins),
        'gap':        fmt_time(gap_min),
        'scores':     scores,
        'app_classifications': {a['name']: classify_app(a['name']) for a in apps}
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
